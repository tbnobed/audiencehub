# Replit Agent prompt: Audience Hub MVP

How to use: create an empty Replit project, upload the `docs/` folder from this bundle into the project root, then paste everything below the line into Replit Agent.

---

You are building **Audience Hub**, an in-house customer data platform (CDP) MVP for OBTV / Trinity Broadcasting Network. It replaces a commercial CDP (Zeta Global) that the team uses for two things: (1) dashboards, segmentation, and activation on our own donor, viewer, and app data, and (2) third-party data enrichment and prospect audiences. This MVP covers the first fully and provides a clean import path for purchased enrichment data to cover the second.

The `docs/` folder is the specification. Read every file in it before writing code. When this prompt and a doc disagree, the doc wins. When a doc is silent, choose the simplest option that keeps the system portable and self-hosted, and note the decision in `docs/DECISIONS.md` (create it).

## Non-negotiable constraints

1. Production runs on our own Linux server with Docker Compose. Replit is only the development environment. The finished repo has to run with `docker compose up -d --build` on a plain Linux host, with no Replit services involved.
2. Do not use Replit Auth, Replit DB, Replit Object Storage, Replit Secrets-specific SDKs, Replit Deployments, or any `@replit/*` or `replit` package. All configuration comes from environment variables documented in `.env.example`.
3. The app makes no outbound network calls at runtime except those a user explicitly configures (webhook destinations, the OIDC provider). That means no CDN scripts, no Google Fonts, no analytics, no telemetry, and no hosted error tracking. All frontend assets, fonts, and icons are bundled through npm (use `@fontsource/*` for fonts, `lucide-react` for icons).
4. PostgreSQL 16 is the only datastore. The background job queue is implemented in Postgres (`SELECT ... FOR UPDATE SKIP LOCKED`). Do not add Redis, Kafka, Celery, or any cloud service.
5. Use only synthetic data. Never ask for or accept real donor data in Replit. Build the seed generator described in `docs/MILESTONES.md` and use it for all development and demos.
6. User input never becomes raw SQL. The segment builder compiles a JSON definition into SQLAlchemy Core expressions against a whitelisted field registry with bound parameters only.

## Stack

- Backend: Python 3.12, FastAPI, SQLAlchemy 2.x (Core for heavy queries, ORM where it helps), Alembic, psycopg 3, Pydantic v2, `phonenumbers`, `email-validator`, `authlib` (OIDC), `cryptography` (Fernet), `pytest`.
- Frontend: React 18, Vite, TypeScript, Tailwind CSS, TanStack Query, TanStack Table, React Router, Recharts, lucide-react.
- Worker: a separate Python process (`python -m app.worker`) running the Postgres-backed job queue plus a simple scheduler loop.
- Packaging: one multi-stage `Dockerfile` (Node builds the frontend; the Python image serves the API and the built static files) and `docker-compose.yml` with `db`, `api`, `worker`, and `backup` services, as specified in `docs/DEPLOYMENT.md`.

## Running inside Replit (development only)

- Use Replit's provisioned Postgres through the `DATABASE_URL` env var for development. Code must not assume anything Replit-specific about it.
- Provide `scripts/dev.sh`, which runs `alembic upgrade head`, then starts uvicorn with reload on 127.0.0.1:8000, the worker, and Vite on 0.0.0.0:5000. Vite proxies `/api`, `/v1`, `/sdk`, and `/auth` to port 8000. Point the `.replit` run command at this script.
- In Replit set `APP_ENV=development`, `GMAIL_STYLE_DOMAINS=gmail.com,googlemail.com,gmail.test`, and throwaway values for `SECRET_KEY`, `FERNET_KEY`, and `PII_HASH_PEPPER`.
- Set `AUTH_MODE=dev` in Replit so a local role picker replaces OIDC. The app has to refuse to start when `AUTH_MODE=dev` and `APP_ENV=production`.
- You cannot run Docker in Replit. Write the Dockerfile and compose file carefully anyway. I will build and test them on my server, so keep them simple and standard.

## Repository layout

```
audience-hub/
  backend/
    app/
      main.py            # FastAPI app, static file serving in production
      config.py          # pydantic-settings, all env vars
      db.py
      auth/              # oidc.py, dev.py, deps.py (role guards)
      models/            # SQLAlchemy models
      api/               # routers: profiles, sources, imports, segments, destinations, dashboards, admin, ingest (v1)
      identity/          # normalize.py, resolver.py, survivorship.py
      traits/            # computed trait registry and SQL
      segments/          # schema.py (pydantic DSL), registry.py (fields), compiler.py
      activation/        # csv_export.py, hashed_audience.py, webhook.py
      jobs/              # queue.py, handlers.py, scheduler.py
      events/            # store.py: every read/write of the events table goes through here
      worker.py
      cli.py             # create-admin, seed
      seed/              # synthetic data generator
    alembic/
    tests/
    pyproject.toml
  frontend/
    src/ (pages, components, api client, theme)
    public/sdk/          # nothing here; the SDK is served by the API at /sdk/ah.js
    package.json
  scripts/ (dev.sh, start-api.sh, start-worker.sh, backup.sh)
  Dockerfile
  docker-compose.yml
  .env.example
  README.md
  docs/ (the spec files, plus DECISIONS.md you maintain)
```

## How to work

- Build strictly in the milestone order in `docs/MILESTONES.md`. Finish each milestone's acceptance checks and tests before starting the next. At the end of each milestone, give me a short summary: what was built, what the tests cover, and any open decisions.
- Write tests alongside the code. Identity resolution, the segment compiler, hashing and normalization, and consent filtering need thorough unit tests (the required cases are listed in the docs).
- Keep performance in mind from the start. Use batch operations, `COPY` for bulk loads, and set-based SQL for computed traits. Avoid per-row round trips on imports.
- Every mutating admin action, every export or activation run, every profile detail view, and every deletion writes to `audit_log`.
- UI follows `docs/UI.md`: a dense, dark, NOC-style operations console. It is a tool for analysts, not a marketing site.
- Keep the README current with setup, env vars, dev and production run instructions, and a short architecture overview.

Start with Milestone 1.
